#!/usr/bin/env python3
"""Build RiFSVR without Gradle. Linux: Python 3, Java 17+, CMake/Ninja, Android SDK/NDK.
SPDX-License-Identifier: GPL-3.0-only
"""
from pathlib import Path
import argparse, hashlib, os, shutil, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parent
UPSTREAM_COMMIT = 'd6aad1e56454a307fd952d8d4dfce05bea7eda84'
NDK_VERSION = '28.2.13676358'

def run(*args, **kwargs):
    print('+', ' '.join(map(str,args)), flush=True)
    subprocess.run([str(x) for x in args], check=True, **kwargs)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--upstream',type=Path,default=ROOT/'vendor'/'FSVR')
    ap.add_argument('--sdk',type=Path,default=Path(os.environ.get('ANDROID_SDK_ROOT',os.environ.get('ANDROID_HOME','/usr/local/lib/android/sdk'))))
    ap.add_argument('--ndk',type=Path)
    ap.add_argument('--keystore',type=Path)
    ap.add_argument('--skip-tests',action='store_true')
    a=ap.parse_args()
    upstream=a.upstream.resolve(); sdk=a.sdk.resolve()
    ndk=(a.ndk or sdk/'ndk'/NDK_VERSION).resolve()
    for p in (upstream/'src/fs1r.h',ndk/'build/cmake/android.toolchain.cmake',sdk/'platforms/android-35/android.jar'):
        if not p.exists():raise FileNotFoundError(str(p))
    out=ROOT/'out';out.mkdir(exist_ok=True)
    generated=upstream/'plugin/generated'
    if not a.skip_tests:
        run('cmake','-G','Ninja','-S',ROOT,'-B',ROOT/'build-host','-DCMAKE_BUILD_TYPE=Release',f'-DFSVR_SOURCE_DIR={upstream}')
        run('cmake','--build',ROOT/'build-host','--target','rifsvr_smoke','--parallel','2')
        with (out/'pruebas-motor.txt').open('w') as log:
            r=subprocess.run([str(ROOT/'build-host/rifsvr_smoke'),str(generated)],stdout=log,stderr=subprocess.STDOUT)
        print((out/'pruebas-motor.txt').read_text(),flush=True)
        if r.returncode:raise RuntimeError(f'Engine smoke test failed: {r.returncode}')
    run('cmake','-G','Ninja','-S',ROOT,'-B',ROOT/'build-arm64','-DCMAKE_BUILD_TYPE=Release',
        f'-DCMAKE_TOOLCHAIN_FILE={ndk}/build/cmake/android.toolchain.cmake','-DANDROID_ABI=arm64-v8a',
        '-DANDROID_PLATFORM=android-29','-DANDROID_STL=c++_static',f'-DFSVR_SOURCE_DIR={upstream}')
    run('cmake','--build',ROOT/'build-arm64','--target','rifsvr','--parallel','2')
    tools=sdk/'build-tools/35.0.0'; androidjar=sdk/'platforms/android-35/android.jar'
    build=ROOT/'build-package';build.mkdir(exist_ok=True)
    assets=build/'assets';assets.mkdir(exist_ok=True)
    for name in ('fs1r_presets.syx','fs1r_performances.syx','fs1r_fseqs.syx'):
        p=generated/name
        if p.read_bytes().startswith(b'version https://git-lfs'):raise RuntimeError('Git LFS placeholder: '+str(p))
        shutil.copy2(p,assets/name)
    for name in ('LICENSE','NOTICE.md'):
        shutil.copy2(upstream/name,assets/name)
    classes=build/'classes';classes.mkdir(exist_ok=True)
    run('javac','-encoding','UTF-8','-source','8','-target','8','-bootclasspath',androidjar,'-d',classes,*sorted((ROOT/'java').rglob('*.java')))
    jar=build/'classes.jar';run('jar','cf',jar,'-C',classes,'.')
    dex=build/'dex';dex.mkdir(exist_ok=True)
    run(tools/'d8','--lib',androidjar,'--min-api','29','--output',dex,jar)
    base=build/'base.apk'
    run(tools/'aapt2','link','-I',androidjar,'--manifest',ROOT/'AndroidManifest.xml','-A',assets,'-o',base)
    unsigned=build/'unsigned.apk';shutil.copy2(base,unsigned)
    with zipfile.ZipFile(unsigned,'a',compression=zipfile.ZIP_DEFLATED) as z:
        z.write(dex/'classes.dex','classes.dex')
        z.write(ROOT/'build-arm64/librifsvr.so','lib/arm64-v8a/librifsvr.so')
    aligned=build/'aligned.apk';run(tools/'zipalign','-P','16','-f','4',unsigned,aligned)
    key=(a.keystore or ROOT/'debug.keystore').resolve()
    if not key.exists():
        run('keytool','-genkeypair','-noprompt','-keystore',key,'-storepass','android','-keypass','android',
            '-alias','androiddebugkey','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=RiFSVR Android Test,O=RiNoize,C=AR')
    apk=out/'RiFSVR-AndroidTest-v0.1.0-arm64.apk'
    run(tools/'apksigner','sign','--ks',key,'--ks-pass','pass:android','--key-pass','pass:android','--ks-key-alias','androiddebugkey','--out',apk,aligned)
    run(tools/'apksigner','verify','--verbose',apk)
    run(tools/'zipalign','-c','-P','16','4',apk)
    run(tools/'aapt','dump','badging',apk)
    meta='RiFSVR Android Test 0.1.0\nUpstream FSVR: '+UPSTREAM_COMMIT+'\nABI: arm64-v8a; min API 29; target API 35; NDK '+NDK_VERSION+'\n'
    meta+='Host engine tests: '+('SKIPPED' if a.skip_tests else 'PASS')+'\nAndroid tablet runtime: NOT TESTED HERE\n'
    (out/'BUILD.txt').write_text(meta,encoding='utf-8')
    shutil.copy2(ROOT/'LEEME.txt',out/'RiFSVR-AndroidTest-LEEME.txt')
    # Corresponding source: only engine/library code and needed data; no GUI/font files.
    source=out/'RiFSVR-AndroidTest-v0.1.0-fuentes.zip'
    with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel in ('src','java'):
            for p in sorted((ROOT/rel).rglob('*')):
                if p.is_file():z.write(p,'RiFSVR/'+str(p.relative_to(ROOT)))
        for rel in ('CMakeLists.txt','AndroidManifest.xml','build.py','LEEME.txt'):
            z.write(ROOT/rel,'RiFSVR/'+rel)
        for p in sorted((upstream/'src').rglob('*')):
            if p.is_file():z.write(p,'RiFSVR/vendor/FSVR/'+str(p.relative_to(upstream)))
        for rel in ('LICENSE','NOTICE.md','plugin/library.cpp','plugin/library.h',
                    'plugin/generated/fs1r_presets.syx','plugin/generated/fs1r_performances.syx','plugin/generated/fs1r_fseqs.syx'):
            z.write(upstream/rel,'RiFSVR/vendor/FSVR/'+rel)
        z.write(upstream/'LICENSE','RiFSVR/LICENSE')
        z.writestr('RiFSVR/UPSTREAM.txt',meta)
        # Deliberately a non-production test key, to allow updating this test APK.
        z.write(key,'RiFSVR/debug.keystore')
    sums=[]
    for p in sorted(out.iterdir()):
        if p.is_file() and p.name!='SHA256SUMS.txt':sums.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
    (out/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n')
    print(meta)
if __name__=='__main__':main()
