// SPDX-License-Identifier: GPL-3.0-only
// Android adaptation. Loading follows FSVR's plugin.cpp followPerf/loadVoiceItem.
#include "synth.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <stdexcept>
#include <vector>
#if defined(__x86_64__) || defined(__i386__)
#include <xmmintrin.h>
#endif
namespace {
struct NoDenormals {
#if defined(__aarch64__)
 uint64_t old=0;
 NoDenormals(){ asm volatile("mrs %0, fpcr":"=r"(old)); asm volatile("msr fpcr, %0"::"r"(old|(1ull<<24))); }
 ~NoDenormals(){ asm volatile("msr fpcr, %0"::"r"(old)); }
#elif defined(__x86_64__) || defined(__i386__)
 unsigned old=_mm_getcsr();
 NoDenormals(){ _mm_setcsr(old|0x8040); }
 ~NoDenormals(){ _mm_setcsr(old); }
#endif
};
std::vector<uint8_t> readBank(const std::string& p) {
 std::vector<uint8_t> b;
 if(!fsvr::readFile(p,b) || b.empty()) throw std::runtime_error("No se pudo leer el banco: "+p);
 return b;
}
void param(fs1r::Device& d,int h,int m,int l,int v) {
 const uint8_t b[]={0xF0,0x43,0x10,0x5E,(uint8_t)h,(uint8_t)m,(uint8_t)l,(uint8_t)((v>>7)&127),(uint8_t)(v&127),0xF7};
 d.sendMidi(b,sizeof b);
}
}
RiSynth::RiSynth(const std::string& folder) {
 factory=fsvr::parseSyx(readBank(folder+"/fs1r_performances.syx"),"Factory");
 factory.voices=fsvr::parseSyx(readBank(folder+"/fs1r_presets.syx"),"").voices;
 factory.fseqs=fsvr::parseSyx(readBank(folder+"/fs1r_fseqs.syx"),"").fseqs;
 if(factory.perfs.size()!=384 || factory.voices.size()!=1408 || factory.fseqs.size()!=90)
  throw std::runtime_error("Bancos incompletos: se esperaban 384 performances, 1408 voices y 90 FSeq.");
 load(false,0);
}
void RiSynth::loadVoice(const fsvr::Item& it,int p) {
 auto m=it.address ? fsvr::readdress(it.syx,0x40+p,0,0) : it.syx;
 if(!dev->loadSyx(m.data(),m.size(),0,p)) throw std::runtime_error("No se pudo cargar la voz "+it.name);
}
void RiSynth::load(bool voice,int index) {
 const int limit=voice?voiceCount():performanceCount();
 if(index<0 || index>=limit) throw std::out_of_range("Preset fuera de rango");
 stopped();
 dev=std::make_unique<fs1r::Device>();
 dev->setSampleRate(48000.0);
 dev->setEchoParameters(false);
 if(!voice) {
  const auto& it=factory.perfs[(size_t)index];
  if(!dev->loadSyx(it.syx.data(),it.syx.size(),0,0)) throw std::runtime_error("Performance invalida");
  const uint8_t* d=it.data();
  for(int p=0;p<4;p++) {
   const int bank=d[192+52*p+1], program=d[192+52*p+2];
   if(bank>=2 && bank<=12) loadVoice(factory.voices[(size_t)((bank-2)*128+program)],p);
  }
  if((d[0x15]&7)!=0 && (d[0x16]&1)!=0) {
   int n=d[0x17];
   if(n>=fseqCount()) throw std::runtime_error("Indice FSeq fuera de rango");
   const auto& f=factory.fseqs[(size_t)n];
   if(!dev->loadSyx(f.syx.data(),f.syx.size(),0,0)) throw std::runtime_error("FSeq invalida");
   param(*dev,0x10,0,0x15,d[0x15]);
  }
 } else {
  // Fresh engine state, with only Part 1 receiving MIDI channel 1. No leftover layers/effects.
  std::vector<uint8_t> state;
  dev->getState(state);
  bool found=false;
  for(size_t i=0;i+411<=state.size();i++) {
   if(state[i]!=0xF0 || state[i+3]!=0x5E || state[i+6]!=0x10) continue;
   std::array<uint8_t,400> p{};
   std::copy_n(state.data()+i+9,400,p.data());
   p[0x15]=0;
   for(int part=0;part<4;part++) {
    int o=192+52*part;
    p[o+1]=part==0 ? (uint8_t)(2+index/128):0;
    p[o+2]=part==0 ? (uint8_t)(index%128):0;
    p[o+3]=part==0 ? 0:127;
    p[o+4]=part==0 ? 0:127;
   }
   auto b=fsvr::bulk(0x10,0,0,p.data(),p.size());
   if(!dev->loadSyx(b.data(),b.size(),0,0)) throw std::runtime_error("No se pudo inicializar Voice");
   found=true; break;
  }
  if(!found) throw std::runtime_error("El motor no devolvio su Performance inicial");
  loadVoice(factory.voices[(size_t)index],0);
 }
 active.store(0); position.store(0); fframes.store(dev->fseqFrames());
 resetRequested.store(true);
}
std::string RiSynth::names(bool voice,int bank) const {
 const auto& v=voice?factory.voices:factory.perfs;
 std::string result;
 for(int i=bank*128;i<(bank+1)*128 && i<(int)v.size();i++) {
  char number[16]; std::snprintf(number,sizeof number,"%03d  ",i%128+1);
  result+=number+v[(size_t)i].name+"\n";
 }
 return result;
}
std::string RiSynth::info() const {
 if(!dev) return "Motor no inicializado";
 std::string s;
 for(int p=0;p<4;p++) {
  if(p) s+="  |  ";
  s+="P"+std::to_string(p+1)+": "+dev->voiceName(p);
 }
 s+="\nFSeq: "; s+=dev->fseqFrames()?dev->fseqName():"ninguna";
 return s;
}
bool RiSynth::enqueue(int s,int a,int b) {
 if(s<0x80 || s>0xFF) return false;
 std::lock_guard<std::mutex> lock(queueMutex);
 if(count==queue.size()) { dropped.fetch_add(1); panicRequested.store(true); return false; }
 queue[writePos]={(uint8_t)s,(uint8_t)(a&127),(uint8_t)(b&127)};
 writePos=(writePos+1)%queue.size(); count++;
 return true;
}
void RiSynth::gain(float v) { if(std::isfinite(v)) desiredGain.store(std::clamp(v,0.0f,1.0f)); }
void RiSynth::applyPanic() {
 if(!dev) return;
 for(int ch=0;ch<16;ch++) { uint8_t b[]={(uint8_t)(0xB0+ch),64,0}; dev->sendMidi(b,3); }
 dev->allNotesOff();
}
void RiSynth::stopped() {
 std::lock_guard<std::mutex> lock(queueMutex);
 count=0; readPos=writePos=0; panicRequested.store(false);
 applyPanic(); active.store(0);
}
void RiSynth::render(float* out,int frames) {
 if(!out || frames<1 || frames>1024 || !dev) throw std::invalid_argument("Bloque de audio invalido");
 NoDenormals denormals;
 const auto t0=std::chrono::steady_clock::now();
 if(resetRequested.exchange(false)) {
  average.store(0); peak.store(0); overruns.store(0); dropped.store(0); clips.store(0); nonfinite.store(0);
 }
 size_t n=0;
 bool doPanic=panicRequested.exchange(false);
 {
  std::unique_lock<std::mutex> lock(queueMutex,std::try_to_lock);
  if(lock.owns_lock()) {
   if(doPanic) { count=0; readPos=writePos; }
   while(count && n<pending.size()) { pending[n++]=queue[readPos]; readPos=(readPos+1)%queue.size(); --count; }
  } else if(doPanic) panicRequested.store(true);
 }
 if(doPanic) applyPanic();
 for(size_t i=0;i<n;i++) {
  const auto& e=pending[i];
  const uint8_t bytes[]={e.s,e.a,e.b};
  int len=e.s>=0xF8?1:((e.s&0xE0)==0xC0?2:3);
  dev->sendMidi(bytes,(size_t)len);
 }
 dev->process(left.data(),right.data(),frames);
 const float target=desiredGain.load();
 uint64_t clipped=0, invalid=0;
 for(int i=0;i<frames;i++) {
  smoothGain+=(target-smoothGain)*0.002f;
  for(int c=0;c<2;c++) {
   float v=(c?right[(size_t)i]:left[(size_t)i])*smoothGain;
   if(!std::isfinite(v)) { v=0; ++invalid; }
   if(v>0.98f || v< -0.98f) { v=std::clamp(v,-0.98f,0.98f); ++clipped; }
   out[i*2+c]=v;
  }
 }
 active.store(dev->activeVoices()); position.store(dev->fseqPosition());
 clips.fetch_add(clipped); nonfinite.fetch_add(invalid);
 double usec=std::chrono::duration<double,std::micro>(std::chrono::steady_clock::now()-t0).count();
 double load=usec/(frames*1000000.0/48000.0)*100;
 average.store(average.load()==0?load:average.load()*0.95+load*0.05);
 peak.store(std::max(peak.load(),load));
 if(load>100) overruns.fetch_add(1);
}
std::array<double,9> RiSynth::stats() const {
 return {average.load(),peak.load(),(double)overruns.load(),(double)dropped.load(),(double)active.load(),
  (double)position.load(),(double)fframes.load(),(double)clips.load(),(double)nonfinite.load()};
}
