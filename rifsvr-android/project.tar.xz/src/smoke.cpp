#include "synth.h"
#include <cmath>
#include <iostream>
#include <chrono>
int main(int argc,char** argv) {
 try {
  if(argc!=2) return 2;
  int failures=fs1r::Device::selfTest();
  if(failures) return 3;
  RiSynth synth(argv[1]);
  std::cout<<"Factory counts "<<synth.performanceCount()<<" "<<synth.voiceCount()<<" "<<synth.fseqCount()<<"\n";
  float out[2048];
  for(int index : {0,13,19,141}) {
   synth.load(false,index); synth.enqueue(0x90,60,100);
   double sum=0, peak=0;
   auto start=std::chrono::steady_clock::now();
   for(int k=0;k<100;k++) {
    synth.render(out,256);
    for(int i=0;i<512;i++){ if(!std::isfinite(out[i]))return 4; sum+=out[i]*out[i];peak=std::max(peak,std::abs((double)out[i])); }
   }
   std::cout<<"Performance "<<index<<" RMS="<<std::sqrt(sum/51200)<<" peak="<<peak<<"\n"<<synth.info()<<"\n";
   if(peak<1e-7)return 5;
   synth.enqueue(0x80,60,0); synth.panic(); synth.render(out,256);
  }
  for(int index:{0,127,256,1407}) {
   synth.load(true,index);synth.enqueue(0x90,60,100);double peak=0;
   for(int k=0;k<50;k++){synth.render(out,256);for(int i=0;i<512;i++)peak=std::max(peak,std::abs((double)out[i]));}
   std::cout<<"Voice "<<index<<" peak="<<peak<<" "<<synth.info()<<"\n";
   if(peak<1e-7)return 6;
  }
  for(int i=0;i<synth.performanceCount();i++) {synth.load(false,i);synth.enqueue(0x90,60,100);synth.render(out,256);}
  synth.stopped();
  std::cout<<"PASS: upstream self-test, all 384 performance loads, 4 sounding performances, native and DX voice paths.\n";
  return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
}
