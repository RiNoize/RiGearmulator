// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include "fs1r.h"
#include "library.h"
#include <array>
#include <atomic>
#include <memory>
#include <mutex>
#include <string>
struct MidiEvent { uint8_t s, a, b; };
class RiSynth {
 public:
  explicit RiSynth(const std::string& folder);
  void load(bool voice, int index); // Call only while the render thread is stopped.
  std::string names(bool voice, int bank) const;
  std::string info() const; // Call only while stopped.
  bool enqueue(int status, int a, int b);
  void panic() { panicRequested.store(true); }
  void resetStats() { resetRequested.store(true); }
  void gain(float value);
  void render(float* interleaved, int frames); // Single owner / one audio thread.
  void stopped(); // Call only after joining the audio thread.
  std::array<double,9> stats() const;
  int performanceCount() const { return (int)factory.perfs.size(); }
  int voiceCount() const { return (int)factory.voices.size(); }
  int fseqCount() const { return (int)factory.fseqs.size(); }
 private:
  void loadVoice(const fsvr::Item&, int part);
  void applyPanic();
  fsvr::Bank factory;
  std::unique_ptr<fs1r::Device> dev;
  std::array<float,1024> left{}, right{};
  std::array<MidiEvent,1024> queue{}, pending{};
  size_t readPos=0, writePos=0, count=0;
  std::mutex queueMutex;
  std::atomic<bool> panicRequested{false}, resetRequested{false};
  std::atomic<float> desiredGain{0.5f};
  float smoothGain=0.5f;
  std::atomic<double> average{0}, peak{0};
  std::atomic<uint64_t> overruns{0}, dropped{0}, clips{0}, nonfinite{0};
  std::atomic<int> active{0}, position{0}, fframes{0};
};
