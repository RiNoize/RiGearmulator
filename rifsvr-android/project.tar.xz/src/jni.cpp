// SPDX-License-Identifier: GPL-3.0-only
#include "synth.h"
#include <jni.h>
#include <exception>
#define JNI(name) Java_com_rinoize_rifsvr_MainActivity_##name
static RiSynth* ptr(jlong h){ return reinterpret_cast<RiSynth*>(h); }
static void error(JNIEnv* e,const char* message) { e->ThrowNew(e->FindClass("java/lang/IllegalStateException"),message); }
extern "C" {
JNIEXPORT jlong JNICALL JNI(nCreate)(JNIEnv* e,jclass,jstring folder){
 const char* s=e->GetStringUTFChars(folder,nullptr); if(!s) return 0;
 std::string path(s); e->ReleaseStringUTFChars(folder,s);
 try { return reinterpret_cast<jlong>(new RiSynth(path)); }
 catch(const std::exception& ex){ error(e,ex.what()); return 0; }
}
JNIEXPORT void JNICALL JNI(nDestroy)(JNIEnv*,jclass,jlong h){ delete ptr(h); }
JNIEXPORT void JNICALL JNI(nLoad)(JNIEnv* e,jclass,jlong h,jboolean voice,jint index){
 try { if(ptr(h)) ptr(h)->load(voice,index); } catch(const std::exception& ex){error(e,ex.what());}
}
JNIEXPORT jstring JNICALL JNI(nNames)(JNIEnv* e,jclass,jlong h,jboolean voice,jint bank){
 try { auto s=ptr(h)?ptr(h)->names(voice,bank):std::string(); return e->NewStringUTF(s.c_str()); }
 catch(const std::exception& ex){error(e,ex.what());return nullptr;}
}
JNIEXPORT jstring JNICALL JNI(nInfo)(JNIEnv* e,jclass,jlong h){ auto s=ptr(h)?ptr(h)->info():std::string(); return e->NewStringUTF(s.c_str()); }
JNIEXPORT void JNICALL JNI(nMidi)(JNIEnv*,jclass,jlong h,jint s,jint a,jint b){if(ptr(h))ptr(h)->enqueue(s,a,b);}
JNIEXPORT void JNICALL JNI(nPanic)(JNIEnv*,jclass,jlong h){if(ptr(h))ptr(h)->panic();}
JNIEXPORT void JNICALL JNI(nStopped)(JNIEnv*,jclass,jlong h){if(ptr(h))ptr(h)->stopped();}
JNIEXPORT void JNICALL JNI(nGain)(JNIEnv*,jclass,jlong h,jfloat g){if(ptr(h))ptr(h)->gain(g);}
JNIEXPORT void JNICALL JNI(nReset)(JNIEnv*,jclass,jlong h){if(ptr(h))ptr(h)->resetStats();}
JNIEXPORT void JNICALL JNI(nRender)(JNIEnv* e,jclass,jlong h,jobject buffer,jint frames){
 void* p=e->GetDirectBufferAddress(buffer); jlong cap=e->GetDirectBufferCapacity(buffer);
 if(!p || frames<1 || frames>1024 || cap<(jlong)frames*8){error(e,"Buffer JNI invalido");return;}
 try { if(ptr(h))ptr(h)->render(static_cast<float*>(p),frames); } catch(const std::exception& ex){error(e,ex.what());}
}
JNIEXPORT jdoubleArray JNICALL JNI(nStats)(JNIEnv* e,jclass,jlong h){
 auto a=ptr(h)?ptr(h)->stats():std::array<double,9>{};
 jdoubleArray out=e->NewDoubleArray(9); if(out)e->SetDoubleArrayRegion(out,0,9,a.data()); return out;
}
}
