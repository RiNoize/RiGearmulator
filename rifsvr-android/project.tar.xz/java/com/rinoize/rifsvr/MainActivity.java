// SPDX-License-Identifier: GPL-3.0-only
package com.rinoize.rifsvr;

import android.app.Activity;
import android.os.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.media.*;
import android.media.midi.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.util.SparseIntArray;
import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public final class MainActivity extends Activity {
 static { System.loadLibrary("rifsvr"); }
 private static native long nCreate(String folder);
 private static native void nDestroy(long h);
 private static native void nLoad(long h,boolean voice,int index);
 private static native String nNames(long h,boolean voice,int bank);
 private static native String nInfo(long h);
 private static native void nMidi(long h,int status,int a,int b);
 private static native void nPanic(long h);
 private static native void nStopped(long h);
 private static native void nGain(long h,float gain);
 private static native void nReset(long h);
 private static native void nRender(long h,ByteBuffer out,int frames);
 private static native double[] nStats(long h);
 private final Handler ui=new Handler(Looper.getMainLooper());
 private final ExecutorService control=Executors.newSingleThreadExecutor();
 private final Object nativeLock=new Object();
 private final AtomicInteger loadTicket=new AtomicInteger();
 private volatile long handle=0;
 private volatile boolean resumed=false,destroyed=false,running=false,wantsAudio=true;
 private volatile AudioTrack track;
 private Thread audioThread;
 private AudioManager audioManager;
 private AudioFocusRequest focus;
 private boolean focusHeld=false;
 private int requestedFrames=512;
 private volatile int actualBuffer=0,actualRate=48000,underruns=0,xrunOffset=0;
 private volatile String audioState="Cargando motor...",lastMidi="Sin mensajes";
 private final AtomicLong midiCount=new AtomicLong();
 private boolean voiceMode=false;
 private int bank=0,program=0;
 private Spinner modeSpinner,bankSpinner,programSpinner,bufferSpinner;
 private TextView monitor,patchInfo,midiInfo;
 private Button audioButton;
 private Piano piano;
 private MidiManager midiManager;
 private MidiManager.DeviceCallback deviceCallback;
 private final Map<String,MidiDevice> devices=new HashMap<>();
 private final Map<String,MidiOutputPort> ports=new HashMap<>();
 private final Set<String> opening=new HashSet<>();
 private final int BG=Color.rgb(20,23,29), FG=Color.rgb(230,235,243), ACCENT=Color.rgb(107,184,216);
 private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
 private void task(Runnable r){
  if(destroyed)return;
  control.execute(()->{try{r.run();}catch(Throwable e){android.util.Log.e("RiFSVR","Control",e);audioState="ERROR: "+e.getMessage();}});
 }
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
  setVolumeControlStream(AudioManager.STREAM_MUSIC);
  audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
  AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
  focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attrs)
   .setOnAudioFocusChangeListener(change->{if(change<0){wantsAudio=false;task(()->stopAudio());}},ui).build();
  int stored=getPreferences(0).getInt("frames",512);
  requestedFrames=(stored==256||stored==512||stored==1024)?stored:512;
  buildUI(); setupMidi();
  task(()->{
   File folder=new File(getFilesDir(),"factory");if(!folder.isDirectory()&&!folder.mkdirs())throw new IllegalStateException("No se pudo crear la carpeta de bancos");
   for(String name:new String[]{"fs1r_presets.syx","fs1r_performances.syx","fs1r_fseqs.syx"}){
    try(InputStream in=getAssets().open(name);OutputStream out=new FileOutputStream(new File(folder,name))){byte[] bytes=new byte[32768];int n;while((n=in.read(bytes))!=-1)out.write(bytes,0,n);}
    catch(IOException e){throw new IllegalStateException(e);}
   }
   String info;
   synchronized(nativeLock){handle=nCreate(folder.getAbsolutePath());if(handle==0)throw new IllegalStateException("No se pudo crear FSVR");info=nInfo(handle);}
   ui.post(()->{if(!destroyed){updatePrograms();patchInfo.setText(info);}});
   startAudio();
  });
  ui.post(ticker);
 }
 private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
 private TextView text(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextColor(FG);t.setTextSize(size);t.setPadding(dp(6),dp(2),dp(6),dp(2));return t;}
 private Button button(String value,Runnable action){Button b=new Button(this);b.setText(value);b.setAllCaps(false);b.setTextSize(12);b.setMinHeight(0);b.setMinimumHeight(0);b.setTextColor(FG);b.setOnClickListener(v->action.run());return b;}
 private Spinner spinner(){Spinner s=new Spinner(this);s.setMinimumHeight(dp(46));return s;}
 private void choices(Spinner s,String[] values){ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);}
 private void listen(Spinner s,java.util.function.IntConsumer f){s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> a){}public void onItemSelected(AdapterView<?> a,View v,int p,long id){f.accept(p);}});}
 private void add(LinearLayout r,View v,float weight){r.addView(v,new LinearLayout.LayoutParams(0,dp(48),weight));}
 private void buildUI(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(8),dp(3),dp(8),dp(3));
  TextView title=text("RiFSVR  /  FS1R Android Test 0.1.0",21);title.setTextColor(ACCENT);root.addView(title);
  ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout browser=row();modeSpinner=spinner();bankSpinner=spinner();programSpinner=spinner();
  choices(modeSpinner,new String[]{"Performance","Voice (1 Part)"});choices(bankSpinner,new String[]{"Banco A","Banco B","Banco C"});choices(programSpinner,new String[]{"Cargando bancos..."});
  add(browser,modeSpinner,1.3f);add(browser,bankSpinner,0.9f);add(browser,programSpinner,2.6f);
  browser.addView(button("<",()->{if(program>0)programSpinner.setSelection(program-1);}),new LinearLayout.LayoutParams(dp(50),dp(48)));
  browser.addView(button(">",()->{if(program<127)programSpinner.setSelection(program+1);}),new LinearLayout.LayoutParams(dp(50),dp(48)));body.addView(browser);
  listen(modeSpinner,p->{boolean next=p==1;if(next==voiceMode)return;voiceMode=next;bank=program=0;String[] bs=new String[next?11:3];for(int i=0;i<bs.length;i++)bs[i]="Banco "+(char)('A'+i);choices(bankSpinner,bs);updatePrograms();requestLoad();});
  listen(bankSpinner,p->{if(p==bank)return;bank=p;program=0;updatePrograms();requestLoad();});
  listen(programSpinner,p->{if(handle==0||p==program)return;program=p;requestLoad();});
  LinearLayout actions=row();audioButton=button("Audio",()->{wantsAudio=!wantsAudio;if(!wantsAudio)piano.releaseAll();task(()->{if(wantsAudio)startAudio();else stopAudio();});});
  add(actions,audioButton,1);add(actions,button("Buscar MIDI USB",()->scanMidi()),1.7f);
  add(actions,button("PANIC",()->{piano.releaseAll();synchronized(nativeLock){if(handle!=0)nPanic(handle);}}),1);
  add(actions,button("Reset contadores",()->{synchronized(nativeLock){if(handle!=0)nReset(handle);}xrunOffset=underruns;midiCount.set(0);}),1.4f);
  bufferSpinner=spinner();choices(bufferSpinner,new String[]{"256 muestras","512 muestras","1024 muestras"});bufferSpinner.setSelection(requestedFrames==256?0:requestedFrames==512?1:2);add(actions,bufferSpinner,1.3f);body.addView(actions);
  listen(bufferSpinner,p->{int n=new int[]{256,512,1024}[p];if(n==requestedFrames)return;requestedFrames=n;getPreferences(0).edit().putInt("frames",n).apply();task(()->{stopAudio();startAudio();});});
  patchInfo=text("Inicializando bancos de fabrica...",12);body.addView(patchInfo);
  monitor=text("",13);monitor.setTypeface(Typeface.MONOSPACE);body.addView(monitor);
  midiInfo=text("MIDI USB: conectá el teclado al hub y pulsá Buscar MIDI USB.",12);body.addView(midiInfo);
  LinearLayout sliders=row();
  slider(sliders,"Volumen",100,50,v->{synchronized(nativeLock){if(handle!=0)nGain(handle,v/100f);}},false);
  slider(sliders,"Modulación CC1",127,0,v->send(0xB0,1,v),false);
  slider(sliders,"Pitch bend",16383,8192,v->send(0xE0,v&127,v>>7),true);body.addView(sliders);
  LinearLayout keys=row();keys.addView(button("Oct -",()->piano.octave(-12)),new LinearLayout.LayoutParams(dp(75),dp(45)));
  CheckBox sustain=new CheckBox(this);sustain.setText("Sustain");sustain.setTextColor(FG);sustain.setOnCheckedChangeListener((v,on)->send(0xB0,64,on?127:0));keys.addView(sustain);
  TextView keyLabel=text("Teclado táctil: canal MIDI 1 · USB conserva los canales",12);keys.addView(keyLabel,new LinearLayout.LayoutParams(0,-2,1));
  keys.addView(button("Oct +",()->piano.octave(12)),new LinearLayout.LayoutParams(dp(75),dp(45)));body.addView(keys);
  piano=new Piano();root.addView(piano,new LinearLayout.LayoutParams(-1,dp(115)));
  setContentView(root);
 }
 private void slider(LinearLayout row,String name,int max,int initial,java.util.function.IntConsumer change,boolean spring){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.addView(text(name,12));SeekBar seek=new SeekBar(this);seek.setMax(max);seek.setProgress(initial);box.addView(seek);
  seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){if(spring)s.setProgress(initial);}public void onProgressChanged(SeekBar s,int v,boolean user){change.accept(v);}});row.addView(box,new LinearLayout.LayoutParams(0,dp(65),1));
 }
 private void updatePrograms(){
  synchronized(nativeLock){if(handle==0||destroyed)return;String names=nNames(handle,voiceMode,bank);choices(programSpinner,names.split("\n"));programSpinner.setSelection(program);}
 }
 private void requestLoad(){
  if(handle==0)return;piano.releaseAll();final boolean mode=voiceMode;final int index=bank*128+program;final int ticket=loadTicket.incrementAndGet();audioState="Cargando preset...";
  task(()->{
   if(ticket!=loadTicket.get())return;
   stopAudio();if(ticket!=loadTicket.get())return;
   String info;synchronized(nativeLock){nLoad(handle,mode,index);info=nInfo(handle);}
   ui.post(()->{if(!destroyed&&ticket==loadTicket.get())patchInfo.setText(info);});
   if(ticket==loadTicket.get())startAudio();
  });
 }
 private void startAudio(){
  if(!resumed||destroyed||!wantsAudio||handle==0||running)return;
  if(audioThread!=null&&audioThread.isAlive())throw new IllegalStateException("El hilo anterior no se detuvo");
  if(!focusHeld){if(audioManager.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){audioState="Otra app tiene el audio. Pulsá Audio para reintentar.";wantsAudio=false;return;}focusHeld=true;}
  final int frames=requestedFrames;final long h=handle;running=true;
  audioThread=new Thread(()->{
   AudioTrack local=null;
   try{
    try{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);}catch(Exception e){android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);}
    int min=AudioTrack.getMinBufferSize(48000,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_FLOAT);
    if(min<=0)throw new IllegalStateException("Android rechazo 48 kHz stereo float");
    local=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
     .setAudioFormat(new AudioFormat.Builder().setSampleRate(48000).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).build())
     .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(Math.max(min,frames*8*4)).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build();
    if(local.getState()!=AudioTrack.STATE_INITIALIZED)throw new IllegalStateException("AudioTrack no inicializado");
    local.setBufferSizeInFrames(Math.max((min+7)/8,frames*2));actualBuffer=local.getBufferSizeInFrames();actualRate=local.getSampleRate();
    track=local;underruns=0;xrunOffset=0;
    ByteBuffer bytes=ByteBuffer.allocateDirect(frames*8).order(ByteOrder.nativeOrder());
    local.write(bytes,frames*8,AudioTrack.WRITE_BLOCKING);bytes.clear();
    local.play();audioState="Audio activo";
    while(running&&!Thread.currentThread().isInterrupted()){
     bytes.clear();nRender(h,bytes,frames);
     while(running&&bytes.hasRemaining()){
      int n=local.write(bytes,bytes.remaining(),AudioTrack.WRITE_BLOCKING);
      if(n<0){if(!running)break;throw new IllegalStateException("AudioTrack write "+n);}if(n==0&&running)Thread.yield();
     }
     underruns=local.getUnderrunCount();
    }
   }catch(Throwable e){audioState="ERROR audio: "+e.getMessage();android.util.Log.e("RiFSVR","Audio",e);}
   finally{running=false;if(local!=null){try{local.pause();local.flush();local.release();}catch(Exception ignored){}}if(track==local)track=null;}
  },"RiFSVR-Audio");audioThread.start();
 }
 private void stopAudio(){
  running=false;AudioTrack t=track;if(t!=null){try{t.pause();}catch(Exception ignored){}}
  Thread thread=audioThread;if(thread!=null){thread.interrupt();try{thread.join(3000);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IllegalStateException(e);}if(thread.isAlive())throw new IllegalStateException("El audio no se detuvo; cerrá la app antes de recargar");}
  audioThread=null;
  synchronized(nativeLock){if(handle!=0)nStopped(handle);}
  if(focusHeld){audioManager.abandonAudioFocusRequest(focus);focusHeld=false;}
  audioState="Audio detenido";
 }
 private void send(int s,int a,int b){
  if(!running||destroyed)return;
  synchronized(nativeLock){if(handle!=0)nMidi(handle,s,a,b);}
 }
 private void receive(int s,int a,int b){
  midiCount.incrementAndGet();
  if(s<0xF8)lastMidi=String.format(Locale.US,"%02X %02X %02X",s,a,b);
  // Program Change needs a factory-bank resolver, not Device's ROM-only PC path.
  // Prototype deliberately selects patches on screen; CC/notes/aftertouch/bend/clock pass through.
  if((s&0xF0)==0xC0)return;
  send(s,a,b);
 }
 private void setupMidi(){
  midiManager=(MidiManager)getSystemService(MIDI_SERVICE);if(midiManager==null)return;
  deviceCallback=new MidiManager.DeviceCallback(){
   @Override public void onDeviceAdded(MidiDeviceInfo info){if(info.getType()==MidiDeviceInfo.TYPE_USB)scanMidi();}
   @Override public void onDeviceRemoved(MidiDeviceInfo info){
    String prefix=info.getId()+":";for(String key:new ArrayList<>(ports.keySet()))if(key.startsWith(prefix))closePort(key);
    opening.removeIf(key->key.startsWith(prefix));
    synchronized(nativeLock){if(handle!=0)nPanic(handle);}showMidiPorts();
   }
  };
  midiManager.registerDeviceCallback(deviceCallback,ui);scanMidi();
 }
 private void scanMidi(){
  if(midiManager==null){midiInfo.setText("Android no expone MIDI en este dispositivo.");return;}
  for(MidiDeviceInfo info:midiManager.getDevices()){
   if(info.getType()!=MidiDeviceInfo.TYPE_USB)continue;
   for(MidiDeviceInfo.PortInfo port:info.getPorts()){
    if(port.getType()!=MidiDeviceInfo.PortInfo.TYPE_OUTPUT)continue;
    final String key=info.getId()+":"+port.getPortNumber();if(ports.containsKey(key)||opening.contains(key))continue;
    opening.add(key);
    midiManager.openDevice(info,device->{
     opening.remove(key);if(device==null)return;
     if(destroyed){try{device.close();}catch(IOException ignored){}return;}
     MidiOutputPort output=device.openOutputPort(port.getPortNumber());
     if(output==null){try{device.close();}catch(IOException ignored){}return;}
     output.connect(new MidiReceiver(){
      private int status=0,need=0,used=0;private final int[] data=new int[2];private boolean sysex=false;
      @Override public void onSend(byte[] msg,int off,int n,long timestamp){
       for(int i=off;i<off+n;i++){
        int v=msg[i]&255;
        if(v>=0xF8){receive(v,0,0);continue;}
        if(v==0xF0){sysex=true;status=used=0;continue;}
        if(v==0xF7){sysex=false;status=used=0;continue;}
        if(sysex){if(v<0x80)continue;sysex=false;}
        if(v>=0x80){
         used=0;if(v>=0xF0){status=0;need=0;continue;}
         status=v;need=((v&0xF0)==0xC0||(v&0xF0)==0xD0)?1:2;continue;
        }
        if(status!=0&&need>0){data[used++]=v;if(used==need){receive(status,data[0],need>1?data[1]:0);used=0;}}
       }
      }
     });
     devices.put(key,device);ports.put(key,output);showMidiPorts();
    },ui);
   }
  }
  showMidiPorts();
 }
 private void showMidiPorts(){if(midiInfo!=null)midiInfo.setText("MIDI USB: "+ports.size()+" entrada(s) · "+lastMidi+" · mensajes "+midiCount.get());}
 private void closePort(String key){MidiOutputPort p=ports.remove(key);MidiDevice d=devices.remove(key);try{if(p!=null)p.close();}catch(IOException ignored){}try{if(d!=null)d.close();}catch(IOException ignored){}}
 private final Runnable ticker=new Runnable(){public void run(){
  if(destroyed)return;double[] s=null;synchronized(nativeLock){if(handle!=0)s=nStats(handle);}
  audioButton.setText(running?"Detener audio":"Iniciar audio");
  if(s!=null)monitor.setText(String.format(Locale.US,
   "%s | %d Hz | bloque %d / cola real %d\nDSP %.1f%%  pico %.1f%%  OV %.0f  XRUN %d  canales %.0f\nFSeq %.0f / %.0f  MIDI perdidos %.0f  clip %.0f  inválidos %.0f",
   audioState,actualRate,requestedFrames,actualBuffer,s[0],s[1],s[2],Math.max(0,underruns-xrunOffset),s[4],s[5],s[6],s[3],s[7],s[8]));
  else monitor.setText(audioState);
  showMidiPorts();ui.postDelayed(this,300);
 }};
 @Override protected void onResume(){super.onResume();resumed=true;task(()->startAudio());}
 @Override protected void onPause(){resumed=false;if(piano!=null)piano.releaseAll();task(()->stopAudio());super.onPause();}
 @Override protected void onDestroy(){
  destroyed=true;resumed=false;ui.removeCallbacks(ticker);if(midiManager!=null&&deviceCallback!=null)midiManager.unregisterDeviceCallback(deviceCallback);
  for(String key:new ArrayList<>(ports.keySet()))closePort(key);
  control.execute(()->{try{stopAudio();synchronized(nativeLock){if(handle!=0){nDestroy(handle);handle=0;}}}catch(Throwable e){android.util.Log.e("RiFSVR","Destroy",e);}});control.shutdown();super.onDestroy();
 }
 private final class Piano extends View{
  final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final SparseIntArray pointers=new SparseIntArray();final int[] refs=new int[128];int base=48;
  final int[] whites={0,2,4,5,7,9,11};final int[] blackAfter={0,1,3,4,5};final int[] blackSemis={1,3,6,8,10};
  Piano(){super(MainActivity.this);setFocusable(true);}
  void octave(int d){releaseAll();base=Math.max(24,Math.min(84,base+d));invalidate();}
  void releaseAll(){for(int i=0;i<128;i++){if(refs[i]>0)send(0x80,i,0);refs[i]=0;}pointers.clear();invalidate();}
  int hit(float x,float y){float w=getWidth()/14f;if(x<0||x>=getWidth()||y<0||y>=getHeight())return -1;
   if(y<getHeight()*0.62f)for(int oct=0;oct<2;oct++)for(int k=0;k<5;k++){float left=(oct*7+blackAfter[k]+0.68f)*w;if(x>=left&&x<left+w*0.64f)return base+oct*12+blackSemis[k];}
   int key=Math.min(13,(int)(x/w));return base+(key/7)*12+whites[key%7];}
  void change(int id,int note){int old=pointers.get(id,-1);if(old==note)return;if(old>=0&&--refs[old]==0)send(0x80,old,0);if(note>=0){if(refs[note]++==0)send(0x90,note,100);pointers.put(id,note);}else pointers.delete(id);invalidate();}
  @Override protected void onDraw(Canvas c){float w=getWidth()/14f;for(int i=0;i<14;i++){int note=base+(i/7)*12+whites[i%7];p.setColor(refs[note]>0?ACCENT:Color.rgb(229,229,223));c.drawRect(i*w+1,0,(i+1)*w-1,getHeight(),p);if(i%7==0){p.setColor(Color.DKGRAY);p.setTextSize(dp(12));c.drawText("C"+(note/12-1),i*w+dp(5),getHeight()-dp(8),p);}}
   for(int oct=0;oct<2;oct++)for(int k=0;k<5;k++){int note=base+oct*12+blackSemis[k];float left=(oct*7+blackAfter[k]+0.68f)*w;p.setColor(refs[note]>0?ACCENT:Color.rgb(26,28,32));c.drawRect(left,0,left+w*0.64f,getHeight()*0.62f,p);}}
  @Override public boolean onTouchEvent(android.view.MotionEvent e){int a=e.getActionMasked(),i=e.getActionIndex();if(a==MotionEvent.ACTION_CANCEL){releaseAll();return true;}if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP){change(e.getPointerId(i),-1);return true;}
   if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN){change(e.getPointerId(i),hit(e.getX(i),e.getY(i)));return true;}
   if(a==MotionEvent.ACTION_MOVE){for(int k=0;k<e.getPointerCount();k++)change(e.getPointerId(k),hit(e.getX(k),e.getY(k)));return true;}return true;}
 }
}
